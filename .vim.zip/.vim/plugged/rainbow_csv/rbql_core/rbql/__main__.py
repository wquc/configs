from .rbql_main import main
main()
